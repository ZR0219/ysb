package web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Userdao;

public class LoginServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public void service(HttpServletRequest request, 
			HttpServletResponse response) 
					throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String username = request.getParameter("text");
		System.out.println(username);
		String password = request.getParameter("password");
		System.out.println(password);
		boolean flag=Userdao.getSelect(username, password);
		System.out.println(flag);
		  //若用户名和密码存在则转发到index.jsp页面，否则重定向到error.jsp页面
		  if (flag) {
		   RequestDispatcher rd = 
					request.getRequestDispatcher("list1.jsp");
			rd.forward(request, response);
		  }else{
		   response.sendRedirect("error.jsp");
		 }
	}

}
