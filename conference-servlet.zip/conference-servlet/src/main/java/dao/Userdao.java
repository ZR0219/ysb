package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.sound.midi.Synthesizer;

import util.DBUtil;

public class Userdao {
	public static boolean getSelect(String userName,String password) {
		  Connection conn=null;
		  boolean flag=false;
		  try {
			  conn=DBUtil.getConnection();
			  Statement state=conn.createStatement();
			  String sql = "select * from user_info"
			  		+ " where username='123' and password='123'"; 
			  ResultSet rs=state.executeQuery(sql);
			  System.out.println(rs);
			  if (rs.next()){
				  flag=true;
			  }
		  }catch (Exception e) {}
		  System.out.println(flag);
		  return flag; 
	}
}
