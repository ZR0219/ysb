package test;

import java.sql.Connection;

import org.junit.Test;

import util.DBUtil;

public class TestCase {
	@Test
	public void test1() throws Exception{
		Connection conn = DBUtil.getConnection();
		System.out.println(conn);
	}
}
